import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Heart, Mail, Lock, User as UserIcon, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "تسجيل الدخول — صحّتك" }] }),
  component: AuthPage,
});

function AuthPage() {
  const { lang } = useI18n();
  const isAr = lang === "ar";
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate({ to: "/" });
  }, [user, loading, navigate]);

  const handleEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { full_name: fullName },
          },
        });
        if (error) throw error;
        toast.success(isAr ? "تم إنشاء الحساب! تحقق من بريدك الإلكتروني" : "Account created! Check your email");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success(isAr ? "تم تسجيل الدخول" : "Signed in");
        navigate({ to: "/" });
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Error";
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  };

  const handleGoogle = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      if (result.error) {
        toast.error(isAr ? "فشل تسجيل الدخول بـ Google" : "Google sign-in failed");
        setBusy(false);
        return;
      }
      if (result.redirected) return;
      navigate({ to: "/" });
    } catch {
      toast.error(isAr ? "خطأ" : "Error");
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 bg-gradient-to-br from-primary-soft/30 via-background to-accent/5">
      <Link to="/" className="flex items-center gap-2 mb-8">
        <div className="h-11 w-11 rounded-xl bg-gradient-primary flex items-center justify-center shadow-soft">
          <Heart className="h-6 w-6 text-primary-foreground" fill="currentColor" />
        </div>
        <span className="text-2xl font-bold">صحّتك</span>
      </Link>

      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 md:p-8 shadow-elevated">
        <h1 className="text-2xl font-bold mb-2">
          {mode === "signin" ? (isAr ? "تسجيل الدخول" : "Sign in") : (isAr ? "إنشاء حساب" : "Sign up")}
        </h1>
        <p className="text-sm text-muted-foreground mb-6">
          {isAr ? "احفظ محادثاتك، تابع حالتك، واستفد بكل المزايا." : "Save your chats, track your health, get full features."}
        </p>

        <Button onClick={handleGoogle} variant="outline" className="w-full mb-4 gap-2" disabled={busy}>
          <svg className="h-4 w-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          {isAr ? "تسجيل الدخول بـ Google" : "Continue with Google"}
        </Button>

        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border" /></div>
          <div className="relative flex justify-center text-xs"><span className="bg-card px-2 text-muted-foreground">{isAr ? "أو" : "or"}</span></div>
        </div>

        <form onSubmit={handleEmail} className="space-y-4">
          {mode === "signup" && (
            <div>
              <Label htmlFor="name">{isAr ? "الاسم" : "Full name"}</Label>
              <div className="relative mt-1">
                <UserIcon className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)} className="ps-9" required />
              </div>
            </div>
          )}
          <div>
            <Label htmlFor="email">{isAr ? "البريد الإلكتروني" : "Email"}</Label>
            <div className="relative mt-1">
              <Mail className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="ps-9" required />
            </div>
          </div>
          <div>
            <Label htmlFor="password">{isAr ? "كلمة المرور" : "Password"}</Label>
            <div className="relative mt-1">
              <Lock className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="ps-9" required minLength={6} />
            </div>
          </div>
          <Button type="submit" disabled={busy} className="w-full bg-gradient-primary">
            {busy && <Loader2 className="h-4 w-4 animate-spin me-2" />}
            {mode === "signin" ? (isAr ? "دخول" : "Sign in") : (isAr ? "إنشاء حساب" : "Create account")}
          </Button>
        </form>

        <button onClick={() => setMode(mode === "signin" ? "signup" : "signin")} className="w-full mt-4 text-sm text-primary hover:underline">
          {mode === "signin"
            ? (isAr ? "ليس لديك حساب؟ أنشئ حساب" : "No account? Sign up")
            : (isAr ? "لديك حساب بالفعل؟ سجّل الدخول" : "Already have an account? Sign in")}
        </button>
      </div>
    </div>
  );
}
